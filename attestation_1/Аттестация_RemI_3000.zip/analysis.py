from pathlib import Path
import random
import sqlite3
import json
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root = Path(__file__).resolve().parent
random.seed(20261106)
db = sqlite3.connect(root/'demo.db')
db.executescript('''DROP VIEW IF EXISTS diagnostic_features;
DROP TABLE IF EXISTS answers; DROP TABLE IF EXISTS sessions;
CREATE TABLE sessions (session_id INTEGER PRIMARY KEY, current_topic TEXT NOT NULL);
CREATE TABLE answers (session_id INTEGER NOT NULL, stage TEXT NOT NULL, topic TEXT NOT NULL, question_number INTEGER NOT NULL, correct INTEGER CHECK(correct IN (0,1)), UNIQUE(session_id,stage,topic,question_number), FOREIGN KEY(session_id) REFERENCES sessions(session_id));''')
for session_id in range(1,3001):
    # Общее условное умение модели одинаково влияет на вопросы по производным.
    ability = random.uniform(0.1, 0.9)
    db.execute('INSERT INTO sessions VALUES (?,?)', (session_id, 'Дифференциальные уравнения'))
    for stage, topic, count, chance in [('initial','equations',2,0.2+0.5*ability),('initial','derivatives',2,ability),('followup','derivatives',3,ability)]:
        for n in range(1,count+1):
            db.execute('INSERT INTO answers VALUES (?,?,?,?,?)',(session_id,stage,topic,n,int(random.random()<chance)))
db.executescript((root/'view.sql').read_text(encoding='utf-8'))
db.commit()
df = pd.read_sql_query('SELECT * FROM diagnostic_features ORDER BY session_id',db)
answer_counts = dict(db.execute('SELECT stage, count(*) FROM answers GROUP BY stage').fetchall())
db.close()
df.to_csv(root/'view_export.csv',index=False,encoding='utf-8-sig')
missing = df.isna().sum().to_dict()
valid=(df.initial_equations_count.eq(2)&df.initial_derivatives_count.eq(2)&df.followup_count.eq(3)&df.initial_equations_correct.between(0,2)&df.initial_derivatives_correct.between(0,2)&df.followup_correct.between(0,3)&df.needs_review.isin([0,1]))
duplicate=int(df.duplicated('session_id').sum())
clean=df[valid].drop_duplicates('session_id').copy()
clean.to_csv(root/'cleaned.csv',index=False,encoding='utf-8-sig')
charts=root/'charts'; charts.mkdir(exist_ok=True)
def plot(col,title,xlabel,name):
    groups=clean.groupby(col)['needs_review'].agg(['sum','count']).sort_index()
    plt.figure(figsize=(7.4,4.2)); x=list(range(len(groups))); pct=groups['sum']/groups['count']*100
    plt.bar(x,pct,color='#486981'); plt.xticks(x,groups.index); plt.ylim(0,100)
    plt.ylabel('Доля с затруднением, %'); plt.xlabel(xlabel); plt.title(title)
    for i,(_,r) in enumerate(groups.iterrows()): plt.text(i,r['sum']/r['count']*100+2,f"{int(r['sum'])}/{int(r['count'])}",ha='center')
    plt.tight_layout(); plt.savefig(charts/name,dpi=160); plt.close()
    return {str(int(k)):{'count':int(v['count']),'review':int(v['sum'])} for k,v in groups.iterrows()}
deriv=plot('initial_derivatives_correct','Первые ответы по производным и дополнительная проверка','Правильных ответов из двух','derivatives.png')
equat=plot('initial_equations_correct','Первые ответы по уравнениям и дополнительная проверка','Правильных ответов из двух','equations.png')
stats={'sessions':len(df),'answers':answer_counts,'missing':{k:int(v) for k,v in missing.items()},'invalid':int((~valid).sum()),'duplicate':duplicate,'clean':len(clean),'target_positive':int(clean.needs_review.sum()),'by_derivatives':deriv,'by_equations':equat}
(root/'results.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(stats,ensure_ascii=False,indent=2))
