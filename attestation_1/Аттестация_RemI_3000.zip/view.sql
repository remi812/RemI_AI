CREATE VIEW diagnostic_features AS
SELECT s.session_id,
       SUM(CASE WHEN a.stage='initial' AND a.topic='equations' THEN 1 ELSE 0 END) AS initial_equations_count,
       SUM(CASE WHEN a.stage='initial' AND a.topic='equations' AND a.correct=1 THEN 1 ELSE 0 END) AS initial_equations_correct,
       SUM(CASE WHEN a.stage='initial' AND a.topic='derivatives' THEN 1 ELSE 0 END) AS initial_derivatives_count,
       SUM(CASE WHEN a.stage='initial' AND a.topic='derivatives' AND a.correct=1 THEN 1 ELSE 0 END) AS initial_derivatives_correct,
       SUM(CASE WHEN a.stage='followup' AND a.topic='derivatives' THEN 1 ELSE 0 END) AS followup_count,
       SUM(CASE WHEN a.stage='followup' AND a.topic='derivatives' AND a.correct=1 THEN 1 ELSE 0 END) AS followup_correct,
       CASE WHEN SUM(CASE WHEN a.stage='followup' AND a.topic='derivatives' THEN 1 ELSE 0 END)=3
            THEN CASE WHEN SUM(CASE WHEN a.stage='followup' AND a.topic='derivatives' AND a.correct=1 THEN 1 ELSE 0 END)<=1 THEN 1 ELSE 0 END
            ELSE NULL END AS needs_review
FROM sessions AS s
LEFT JOIN answers AS a ON a.session_id=s.session_id
GROUP BY s.session_id;
